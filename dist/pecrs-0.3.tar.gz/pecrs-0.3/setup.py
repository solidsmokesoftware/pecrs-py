# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['pecrs']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'pecrs',
    'version': '0.3',
    'description': 'Pythonic Entity Collision Resolution System',
    'long_description': '![logo](https://raw.githubusercontent.com/solidsmokesoftware/pecrs-py/master/logo.png)\n\n# Pythonic Entity Collision Resolution System\n\npecrs is a pure Python 2D physics system with a focus on top-down games and simple platformers. \n\nPure Python makes pecrs portable and easy to modify to suit your own needs.\n\nFocused use-case makes pecrs simple to learn and use.\n\nSeamless integration with Pyglet\n\n# Installation\n\nVia pip\n\n`python3 -m pip install pecrs`\n\n# Quickstart\n```python\n\nfrom pecrs import *\n\ncontroller = Controller()\nbodyA = controller.make(Body, 0, 0, 32, 32)\nbodyB = controller.make(Body, 10, 0, 32, 32)\n\ncollision = controller.space.check_body(bodyA)\nprint(f"Is something colliding with bodyA? {collision}")\n\ncollisions = controller.space.collisions_with(bodyB)\nprint(f"Who is colliding with bodyB? {collisions}")\n\ncontroller.place(bodyB, 100, 0)\n\ncollision = controller.space.check_bodies(bodyA, bodyB)\nprint(f"Are bodyA and bodyB colliding? {collision}")\n```\n\n# Structual Overview\n\nThe core functionality of pecrs is provided by Shapes. Shape are datatypes for describing the physical properties of a Body. \n\nAt the intermediate level of organization are Bodies and the Collider. A Body consists of a Shape and an id(Provided by Index) and is the cornerstone unit of simulation. The Collider works with Shapes or Bodies to detect intersections.\n\nAbove that exists the Space. The Space optimizes collision detection using a Spatialhash.\n\nAt the highest level exists the Controller. The Controller creates Bodies in a Space and handles their interactions, as well as the physics simulation itself. The Controller is follows Object-Oriented design principles and provides callbacks into all of its functionality that can be easily extended. \n\n# Real-world Usage\n\n![demo](https://raw.githubusercontent.com/solidsmokesoftware/pecrs-py/master/pyglet_demo.gif)\n\n```python\n\nfrom pecrs import *\nimport pyglet\n\n\nclass Dude(Body):\n   def __init__(self, id, sprite):\n      super().__init__(id, sprite)\n      self.speed = 100\n      self.moving = True\n\n\nclass Objects(Controller):\n   def __init__(self, batch):\n      super().__init__()\n      self.batch = batch\n      self.blue_image = pyglet.resource.image("blue_rect.png")\n      self.red_image = pyglet.resource.image("red_rect.png")\n\n   def make_dude(self, x, y, dx=0, dy=0):\n      sprite = pyglet.sprite.Sprite(self.blue_image, x=x, y=y, batch=self.batch)\n      self.make_with(Dude, sprite, dx=dx, dy=dy)\n\n   def on_collision(self, body, collisions):\n      body.shape.image = self.red_image\n      \n\nclass Game:\n   def __init__(self):\n      self.window = pyglet.window.Window(400, 300)\n      self.batch = pyglet.graphics.Batch()\n\n      self.objects = Objects(self.batch)\n      self.objects.make_dude(0, 150, dx=1)\n      self.objects.make_dude(300, 150)\n\n      pyglet.clock.schedule_interval(self.run, 1.0/60)\n      pyglet.app.run()\n\n   def run(self, delta):\n      self.objects.step(delta)\n      self.window.clear()\n      self.batch.draw()\n\ngame = Game()\n```\n\n# Documentation\n\nhttps://solidsmokesoftware.github.io/pecrs/\n\n# Demonstration\n\n(Currently broken)\n\nhttps://github.com/solidsmokesoftware/solconomy\n\n![solconomy](https://camo.githubusercontent.com/de20b3b2014d20a8746f7346e777e323586d5a35/68747470733a2f2f692e696d6775722e636f6d2f566277677664372e706e67)\n\n# Requirements\n\nTested with Python3.6.9\n',
    'author': 'Solid Smoke Software',
    'author_email': 'solid.smoke.software@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/solidsmokesoftware/pecrs-py',
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.6.9,<4.0.0',
}


setup(**setup_kwargs)
